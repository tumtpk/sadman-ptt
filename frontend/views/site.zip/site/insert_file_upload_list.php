<?php $type = isset($_GET['type']) ?  $_GET['type'] : (isset($_POST['type']) ? $_POST['type'] : ''); ?>

<?php if ($type=='insert'){
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Headers: Content-Type, x-xsrf-token');
	header('Content-Type: application/json');
	$bucket = $_GET['namebucket'];
	$file_name = $_GET['namefile'];
	$form_id = $_GET['form_id'];
	$sql = "INSERT INTO file_upload_list (bucket,file_name, status, form_id) VALUES ('".$bucket."','".$file_name."', '0', '".$form_id."')";
	$query = Yii::$app->db->createCommand($sql);
	if ($query->execute()) {
		$output['status'] = 1;
	}else{
		$output['status'] = 0;
	}
	echo json_encode($output);
} ?>


<?php if ($type=='show'){
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Headers: Content-Type, x-xsrf-token');
	header('Content-Type: application/json');
	$query = "SELECT * FROM file_upload_list WHERE form_id = '".$_GET['form_id']."' ORDER BY id DESC";
	$result = Yii::$app->db->createCommand($query)->queryAll();
	$count = 0;
	$resultArray = array();
	foreach ($result as $row) {
		$count ++;
		$resultArray[] = array(
			'file_id' => $row['id'],
			'file_name' => $row['file_name'],
			'bucket' => $row['bucket']
		);
	}

	echo json_encode($resultArray);
} ?>

<?php
if ($type == "delete") {
	if(isset($_GET["file_id"]))
	{
		$query = "DELETE FROM file_upload_list WHERE id = '".$_GET["file_id"]."'";
		$result = Yii::$app->db->createCommand($query)->execute();
	}
}
?>

<?php
if ($type == "insert_eform") {
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Headers: Content-Type, x-xsrf-token');
	header('Content-Type: application/json');
	if(isset($_POST["form_id"]))
	{
		$query = "
		INSERT INTO `eform_data`(`form_id`, `data_json`) 
		VALUES ('".$_POST["form_id"]."','[".$_POST["data_json"]."]')";
		$result = Yii::$app->db->createCommand($query)->execute();
		$id = Yii::$app->db->getLastInsertID();
		$last_id = array("id_sql_eform"=>$id);
		$na = array_merge($_POST["data_object"],$last_id);


		$manager = new MongoDB\Driver\Manager("mongodb://freeman:abcd1234@database:27017");
		$bulk = new MongoDB\Driver\BulkWrite();
		$bulk->insert($na);
		$writeConcern = new MongoDB\Driver\writeConcern(MongoDB\Driver\WriteConcern::MAJORITY, 100);
		$result = $manager->executeBulkWrite('textx.eform_data', $bulk);

		if ($result) {
			$output['status'] = 1;
			$output['id_sql_eform'] = $id;
		}else{
			$output['status'] = 0;
		}

		echo json_encode($output);

	}
}

if ($type == "update_eform") {
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Headers: Content-Type, x-xsrf-token');
	header('Content-Type: application/json');
	if(isset($_POST["id_sql_eform"]))
	{
		$id_sql_eform = array("id_sql_eform"=>$_POST["id_sql_eform"]);
		$insert_new = array_merge($_POST["data_object"],$id_sql_eform);

		$query = "
		UPDATE `eform_data` SET data_json='[".$_POST["data_json"]."]' WHERE id = '".$_POST["id_sql_eform"]."'";
		$result = Yii::$app->db->createCommand($query);
		if ($result->execute()) {
			$manager = new MongoDB\Driver\Manager("mongodb://freeman:abcd1234@database:27017");
			$bulk = new MongoDB\Driver\BulkWrite();
			$bulk->delete(['id_sql_eform' => $_POST["id_sql_eform"]]);
			$bulk->insert($insert_new);
			$writeConcern = new MongoDB\Driver\writeConcern(MongoDB\Driver\WriteConcern::MAJORITY, 100);
			$result = $manager->executeBulkWrite('textx.eform_data', $bulk);

			if ($result) {
				$output['status'] = 1;
			}else{
				$output['status'] = 0;
			}

			echo json_encode($output);
		}
	}
}


if ($type == "delete_eform") {
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Headers: Content-Type, x-xsrf-token');
	header('Content-Type: application/json');
	if(isset($_GET["id_sql_eform"]))
	{
		$id_sql_eform = $_GET["id_sql_eform"];
		$result = Yii::$app->db->createCommand("DELETE FROM `eform_data` WHERE id = '$id_sql_eform'");
		if ($result->execute()) {
			$manager = new MongoDB\Driver\Manager("mongodb://freeman:abcd1234@database:27017");
			$bulk = new MongoDB\Driver\BulkWrite();
			$bulk->delete(['id_sql_eform' => $id_sql_eform]);
			$writeConcern = new MongoDB\Driver\writeConcern(MongoDB\Driver\WriteConcern::MAJORITY, 100);
			$result = $manager->executeBulkWrite('textx.eform_data', $bulk);

			if ($result) {
				$output['status'] = 1;
			}else{
				$output['status'] = 0;
			}

			echo json_encode($output);
		}
	}
}
?>
