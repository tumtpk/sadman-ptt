<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\mongodb\Query;
?>

<!doctype html>
<html lang="en" dir="ltr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">

	<link rel="icon" href="favicon.ico" type="image/x-icon"/>

	<title>:: TextX :: Login</title>

	<!-- Bootstrap Core and vandor -->
	<link rel="stylesheet" href="../../html-version/assets/plugins/bootstrap/css/bootstrap.min.css" />

	<!-- Core css -->
	<link rel="stylesheet" href="../../html-version/assets/css/main.css"/>
	<link rel="stylesheet" href="../../html-version/assets/css/theme1.css"/>

</head>
<body class="font-montserrat sidebar_dark">

	<div class="auth">
		<div class="auth_left">
			<div class="card">
				<div class="text-center mb-2">
					<a class="header-brand" href="index.html"><i class="fe fe-command brand-logo"></i></a>
				</div>
				<?php $form = ActiveForm::begin([
					'id' => 'login-form',
					'fieldConfig' => [
						'options' => [
							'tag' => false,
						],
					],
				]); 
				?>
				<div class="card-body">
					<div class="card-title"><center>TextX - Login</center></div>
                   <!--  <div class="form-group">
                        <select class="custom-select">
                            <option>ผู้ดูแลระบบ</option>
                            <option>ผู้บังคับบัญชา</option>
                            <option>เจ้าหน้าที่ปฏิบัติงาน</option>
                        </select>
                    </div> -->
                    <div class="form-group">
                    	<!-- <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Username"> -->
                    	<label class="form-label">ชื่อผู้ใช้งาน</label>
                    	<?=$form->field($model, 'username')->textInput(['maxlength' => 30,'aria-describedby' => 'emailHelp', 'class' => 'form-control','placeholder' => 'กรุณากรอกชื่อผู้ใช้งาน','id'=>'exampleInputEmail1'])->label(false);?>
                    </div>
                    <div class="form-group">
                    	<label class="form-label">รหัสผ่าน<a href="forgot-password.html" class="float-right small">ลืมรหัสผ่าน</a></label>
                    	<!-- <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password"> -->
                    	<?=$form->field($model, 'password')->passwordInput(['maxlength' => 30,'class' => 'form-control','placeholder' => 'กรุณากรอกรหัสผ่าน','id'=>'exampleInputPassword1'])->label(false);?>
                    </div>
                    <div class="form-group">
                    	<!-- <label class="custom-control custom-checkbox"> -->
                    		<!-- <input type="checkbox" class="custom-control-input" /> -->
                    		<?= $form->field($model, 'rememberMe',['options' => ['class' =>'custom-control-input']])->checkbox(); ?>
                    		<!-- <span class="custom-control-label">Remember me</span> -->
                    		<!-- </label> -->
                    	</div>
                    	<div class="form-footer">
                    		<!-- <a href="index.html" class="btn btn-primary btn-block" title="">เข้าสู่ระบบ</a> -->
                    		<?=Html::submitButton('เข้าสู่ระบบ', ['class' => 'btn btn-primary btn-block', 'name' => 'login-button'])?>
                    	</div>
                    </div>
                    <?php ActiveForm::end();?>
                    <div class="text-center text-muted">
                    	ยังไม่มีชื่อผู้ใช้งาน? <a href="register.html">ลงทะเบียน</a>
                    </div>
                </div>        
            </div>
            <div class="auth_right">
            	<div class="carousel slide" data-ride="carousel" data-interval="3000">
            		<div class="carousel-inner">
            			<?php
            			$sql = Yii::$app->db->createCommand("SELECT * FROM `carousel_text` ORDER BY slot ASC")->queryAll();
            			$i=1;
            			foreach ($sql as $row){

            				if ($i==1) {
            					$activeClass = "active";
            				}else{
            					$activeClass = "";
            				}

            				?>
            				<div class="carousel-item <?=$activeClass;?>">
            					<img src="<?='/textx/frontend/web/uploads/'.$row['images'];?>" class="img-fluid" alt="login page"/>
            					<div class="px-4 mt-4">
            						<h4><?=$row['name'];?></h4>
            						<p><?=$row['detail'];?></p>
            					</div>
            				</div>
            			<?php $i++; } ?>


            		</div>
            	</div>
            </div>
        </div>

        <script src="../../html-version/assets/bundles/lib.vendor.bundle.js"></script>
        <script src="../../html-version/assets/js/core.js"></script>
    </body>
    </html>