<?php
use yii\helpers\Html;
$this->title = 'สถิติข้อมูลผู้ใช้งานระบบ';
$token = "2ffa459adcc37176dbf93a82addf61dc";
$auth = "Authenticator=>".$token."".date("Ymd");
?>
<h4><?= Html::encode($this->title);?></h4>
<div class="tab-content mt-3">
	<div class="tab-pane fade show active" id="Accounts-Invoices" role="tabpanel">
		<div class="row clearfix">
			<div class="col-md-4">
				<div class="card">
					<div class="card-body ribbon">
						<div class="ribbon-box azure">
							<i class="icon-users"></i> 
						</div>
						<a href="javascript:void(0);" class="my_sort_cut text-muted">
							<div class="m-0 text-center h1 text-azure counter">
								<?=$userAll = Yii::$app->db->createCommand("SELECT COUNT(*) FROM users")->queryScalar();?>
							</div>
							<span class="h6">ผู้ใช้งานทั้งหมด</span>
						</a>
						<div class="d-flex">
							<small class="text-muted">คน</small>
							<div class="ml-auto">
								<i class="fa fa-caret-up"></i> 100%
							</div>
						</div>
					</div>
				</div>
			</div>                
			<div class="col-md-4">
				<div class="card">
					<div class="card-body ribbon">
						<div class="ribbon-box cyan">
							<i class="icon-user-following"></i></div>
							<a href="javascript:void(0);" class="my_sort_cut text-muted">
								<div class="m-0 text-center h1 text-cyan counter">
									<?=$admin = Yii::$app->db->createCommand("SELECT COUNT(*) FROM users WHERE role = 1")->queryScalar();?>
								</div>
								<span class="h6">ผู้ดูแลระบบ</span>
							</a>
							<div class="d-flex">
								<small class="text-muted">คน</small>
								<div class="ml-auto">
									<i class="fa fa-caret-up"></i> 
									<?php 
									$percentage = $admin;
									$totalWidth = $userAll;

									$per_admin = ($percentage * 100) / $totalWidth;
									echo number_format($per_admin, 2, '.', '').'%';

									?>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="card">
						<div class="card-body ribbon">
							<div class="ribbon-box danger">
								<i class="icon-user"></i></div>
								<a href="javascript:void(0);" class="my_sort_cut text-muted">
									<div class="m-0 text-center h1 text-danger counter">
										<?=$users = Yii::$app->db->createCommand("SELECT COUNT(*) FROM users WHERE role = 2")->queryScalar();?>
									</div>

									<span class="h6">ผู้ใช้งานทั่วไป</span>
								</a>
								<div class="d-flex">
									<small class="text-muted">คน</small>
									<div class="ml-auto">
										<i class="fa fa-caret-up"></i>
										<?php 
										$percentage = $users;
										$totalWidth = $userAll;

										$per_users = ($percentage * 100) / $totalWidth;
										echo number_format($per_users, 2, '.', '').'%';

										?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>


				<div class="row clearfix row-deck">
					<div class="col-xl-6 col-lg-12 col-md-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">กราฟแท่งประเภทผู้ใช้งาน</h3>
							</div>
							<div class="card-body">
								<div id="chart-bar-stat" style="height: 250px"></div>
							</div>
						</div>
					</div>

					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">กราฟวงกลมประเภทผู้ใช้งาน</h3>
							</div>
							<div class="card-body">
								<div id="chart-donut" style="height: 16rem"></div>
							</div>
						</div>
					</div>

					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">My Balance</h3>
							</div>
							<div class="card-body">
								<span>Balance</span>
								<h4>$<span class="counter">20,508</span></h4>
								<div id="apexspark1" class="mb-4"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>


		<h4>สถิติข้อมูลการเข้าใช้งานระบบ</h4>

		<div class="tab-content mt-3">
			<div class="tab-pane fade show active" id="Accounts-Invoices" role="tabpanel">
				<div class="row clearfix">
					<div class="col-md-8">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">กราฟแท่งสถิติการเข้าใช้งานระบบ(แยกตามเดือน)</h3>
							</div>
							<div class="card-body ribbon">
								<div id="chart-area" style="height: 16rem"></div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">Default <small>Taken from: https://github.com/JeremyFagis/dropify</small>
								</h3>
							</div>
							<div class="card-body ribbon">
								----
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>


		<script>
			$(document).ready(function(){
				var chart = c3.generate({
            bindto: '#chart-bar-stat', // id of chart wrapper
            data: {
            	columns: [
                    // each columns data
                    ['data1', <?=$admin?>],
                    ['data2', <?=$users?>]
                    ],
                type: 'bar', // default type of chart
                colors: {
                	'data1': '#2FA2BC',
                	'data2': '#A6CA16'
                },
                names: {
                    // name of each serie
                    'data1': 'ผู้ดูแลระบบ',
                    'data2': 'ผู้ใช้งานทั่วไป'
                }
            },
            axis: {
            	x: {
            		type: 'category',
                    // name of each category
                    categories: ['ประภทผู้ใช้งาน']
                },
            },
            bar: {
            	width: 16
            },
            legend: {
                show: true, //hide legend
            },
            padding: {
            	bottom: 0,
            	top: 0
            },
        });

				$(document).ready(function(){
					var chart = c3.generate({
            bindto: '#chart-donut', // id of chart wrapper
            data: {
            	columns: [
                    // each columns data
                    ['data1', <?=$admin?>],
                    ['data2', <?=$users?>]
                    ],
                type: 'donut', // default type of chart
                colors: {
                	'data1': '#E8769F',
                	'data2': '#595278'
                },
                names: {
                    // name of each serie
                    'data1': 'ผู้ดูแลระบบ',
                    'data2': 'ผู้ใช้งานทั่วไป'
                }
            },
            axis: {
            },
            legend: {
                show: true, //hide legend
            },
            padding: {
            	bottom: 0,
            	top: 0
            },
        });
				});


				var url = "../webservice/stat_users_log_year.php?auth=<?=$auth?>";

				var json = null;
				var json = $.ajax({
					url: url,
					global: false,
					dataType: "json",
					async:false,
					success: function(msg){
						return msg;
					}
				}
				).responseJSON;
				console.log(json);
				$(document).ready(function(){
			var chart = c3.generate({
            bindto: '#chart-area', // id of chart wrapper
            data: {
            	columns: [
                    // each columns data
                    json,
                    ],
                type: 'bar', // default type of chart
                colors: ['#cedd7a'],

                names: ['จำนวนการเข้าใช้งาน(ครั้ง)'],
            },

            axis: {
            	x: {
            		type: 'category',
                    // name of each category
                    categories: ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sept','Oct','Nov','Dec'],
                },

            },
            legend: {
                show: false, //hide legend
            },
            padding: {
            	bottom: 0,
            	top: 0
            },

        });
				});
			});
		</script>
