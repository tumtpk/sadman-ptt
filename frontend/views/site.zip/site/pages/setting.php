<?
    use app\models\Setting;
    use yii\helpers\Json;
    header('Content-Type: application/json');
    $Setting = Setting::find()
    ->where(['setting_status' => 1])
    ->orderBy('id')
    ->all();
    echo Json::encode($Setting);

?>