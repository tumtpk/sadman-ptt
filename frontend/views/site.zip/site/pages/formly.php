<div id="div1"><h2>Let jQuery AJAX Change This Text</h2></div>
<script>
$(document).ready(function(){
  
    $("#div1").load("http://117.121.213.103/textx/ngx-formly-test/");

});
</script>